#The function returns the proportion of every variable being selected
library(ncvreg)
library(cluster)
library(grpreg)
library(MASS)
rPGBS=function(X,y,lambda=numeric(0),kmin=round(0.5*dim(X)[2]), kmax=round(0.8*dim(X)[2]),epoch=20, fam=c("binomial","gaussian"),bilevelFUN=NA,cMCP=TRUE, groupFUN=NA){
  # X is the design matrix (nXp)
  # y is the response vector (nX1)
  # lambda is the tuning parameter vector
  # kmin and kmax are mininmum and maximum group number
  # epoch is the repeated number
  # bilevelFUN is bilevel penalization function to used. Here we use "cMCP" or "gel"
  # cMCP, cMCP penalty is used otherwise "gel" is used,  if bilevelFUN is not available.
  # groupFUN is a function to cluster variables into different groups. Here we use 'PAM' as a default
  p=dim(X)[2]
  cv_lasso=cv.ncvreg(X,y, family=fam, penalty='lasso',alpha=1)
  if (length(lambda)==0)
    lambda=exp(seq(log(cv_lasso$lambda[1]), log(0.001*cv_lasso$lambda[1]),length=100))
  active=rep(0,p)
  kvec=sample(kmin, kmax, epoch)
  for (i in 1:epoch) {
    active.tp=rep(0,p)
    k=kvec[i]
    if (is.na(groupFUN))
      grp <- pam(t(X),k=k,diss=FALSE, cluster.only=T,do.swap = FALSE)
    else
      grp <- groupFUN(t(X),k=k)

    if (is.na(bilevelFUN)){
      if (cMCP)
        cvobj=cv.grpreg(X, y, group=grp, penalty='cMCP', family= fam, lambda=lambda)
      else
        cvobj=cv.grpreg(X, y, group=grp, penalty='gel', family= fam, lambda=lambda)
    }
    else{
      cvobj=bilevelFUN(X, y, group=grp,  family= fam, lambda=lambda)
    }
    opt=which(cvobj$lambda==cvobj$lambda.min)
    b.est=cvobj$fit$beta[-1,opt]
    active.tp[abs(b.est)>0.001]=1 #Changes non-zero coefficients to 1
    active=active+active.tp
  }
  prop=active/epoch;
  return(prop)
}
